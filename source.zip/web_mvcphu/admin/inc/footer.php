 <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">
        <p>
         &copy; Copyright <a href="http://trainingwithliveproject.com">@2019</a>. Shop Công Nghệ.
        </p>
    </div>
</body>
</html>
